
class Teacher:
    def __init__(self, first_name: str, last_name: str, title: str, zhz: bool) -> None:
        self.first_name = first_name
        self.last_name = last_name
        self.title = title
        self.zhz = zhz