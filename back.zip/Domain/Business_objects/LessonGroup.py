
class LessonGroup:
    def __init__(self, number: str, form: int, week_day: int, building: str, room: str, hour: str) -> None:
        self.number = number
        self.form = form
        self.week_day = week_day
        self.building = building
        self.room = room
        self.hour = hour
