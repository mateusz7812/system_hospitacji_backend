
class Course:
    def __init__(self, code: str, name: str, degree: int, form: int, semester: int) -> None:
        self.code = code
        self.name = name
        self.degree = degree
        self.form = form
        self.semester = semester
