from enum import Enum

class ProtocolStatus(Enum):
    UTWORZONY = 0
    EDYTOWANY = 1
    WYSTAWIONY = 2
    PODPISANY = 3
    ODWOLANY = 4