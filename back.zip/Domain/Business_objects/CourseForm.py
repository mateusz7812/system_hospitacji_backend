
from enum import Enum

class CourseForm(Enum):
    FULL_TIME = 0
    EXTRAMURAL = 1