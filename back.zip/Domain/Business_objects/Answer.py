
class Answer():
    def __init__(self, text: str, question_id: str) -> None:
        self.text = text
        self.question_id = question_id